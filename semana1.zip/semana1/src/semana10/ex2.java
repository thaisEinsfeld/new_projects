package semana10;
import java.util.Scanner;
import java.util.ArrayList;

public class ex2 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		ArrayList<String> nomes = new ArrayList();
		
		System.out.println("Insira os nomes: ");
		nomes.add(ler.next());
		nomes.add(ler.next());
		nomes.add(ler.next());
		
		//remover o 3 elemento
		nomes.remove(2);
		System.out.println(nomes);
		
		//pesquisando elemento
		System.out.println("Insira o nome da cor que deseja pesquisar: ");
		String nome = ler.next();
		for(int i =0;i<nomes.size();i++) {
			while(nomes.get(i).equals(nome)) {
				System.out.println(nome);
				break;
			}
			System.out.println("Não existe esse nome no array");
		}
	}

}
