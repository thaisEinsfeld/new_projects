package semana10;
import java.util.Scanner;
import java.util.ArrayList;

public class ex1 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		ArrayList<String> cores = new ArrayList();
		
		System.out.println("Insira as cores: ");
		cores.add(ler.next());
		cores.add(ler.next());
		cores.add(ler.next());
		
		//mostrando cores sem estar organizado
		System.out.println("Mostrando as cores:");
		System.out.println(cores);
		
		//recuperando elemento em uma posição
		String corPosicao = cores.get(0);
		System.out.println("A primeira cor é: "+corPosicao);
		
		//retorna total de elementos organizado
		for(int i = 0;i<cores.size();i++) {
			System.out.println("Cores: "+cores.get(i));
		}
		
		//removendo a primeira cor e mostrando na tela
		cores.remove(0);
		System.out.println(cores);
		
		//atualizar um elemento com outro
		System.out.println("Insira o nome da cor que deseja atualizar: ");
		String nomeCor = ler.next();
		for(int i =0;i<cores.size();i++) {
			if(cores.get(i).equals(nomeCor)) {
				System.out.println("Nome atualizado: ");
				String newName = ler.next();
				cores.set(i, newName);
				System.out.println(cores);
			}
		}
				
	}

}
