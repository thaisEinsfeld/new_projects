package semana10;
import java.util.ArrayList;
import java.util.List;
public class Disciplina {
	ArrayList<Aluno> alunos = new ArrayList();

	public Disciplina(ArrayList<Aluno> alunos) {
		this.alunos = alunos;
	}
		
	 public void adicionarAluno(Aluno aluno) {
	        alunos.add(aluno);
	}
	
	 public void exibirNotas() {
	        for (Aluno aluno : alunos) {
	            System.out.println("Nome: " + aluno.getName() + ", Nota: " + aluno.getNota(aluno.getGa(),aluno.getGb()));
	        }
	 }
	 
	 public double calculaMedia() {
	        double somaNotas = 0;
	        int totalAlunos = 0;

	        for (Aluno aluno : alunos) {
	            somaNotas += aluno.getNota(aluno.getGa(), aluno.getGb());
	            totalAlunos++;
	        }

	        if (totalAlunos > 0) {
	            return somaNotas / totalAlunos;
	        } else {
	            return 0.0; 
	        }
	    }

	    public void exibirAprovados() {
	        System.out.println("Alunos aprovados:");
	        for (Aluno aluno : alunos) {
	            if (aluno.getNota(aluno.getGa(), aluno.getGb()) >= 6.0) {
	                System.out.println("Nome: " + aluno.getName() + ", Nota: " + aluno.getNota(aluno.getGa(), aluno.getGb()));
	            }
	        }
	    }
	 
}
