package semana10;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class exe3 {
    public static void main(String[] args) {
        LinkedList<String> listaDeCompras = new LinkedList<>();

        // Adicionando elementos ao final da LinkedList
        listaDeCompras.add("Maçãs");
        listaDeCompras.add("Bananas");
        listaDeCompras.add("Leite");
        listaDeCompras.add("Pão");

        // Iterando todos os elementos na LinkedList
        System.out.println("Iterando todos os elementos:");
        for (String item : listaDeCompras) {
            System.out.println(item);
        }

        // Iterando a partir de uma posição específica (índice 1)
        int startIndex = 1;
        ListIterator<String> iterator = listaDeCompras.listIterator(startIndex);
        System.out.println("\nIterando a partir da posição " + startIndex + ":");
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        // Iterando na ordem inversa
        ListIterator<String> reverseIterator = listaDeCompras.listIterator(listaDeCompras.size());
        System.out.println("\nIterando na ordem inversa:");
        while (reverseIterator.hasPrevious()) {
            System.out.println(reverseIterator.previous());
        }

        // Inserindo elementos na primeira e última posição
        listaDeCompras.addFirst("Cereais");
        listaDeCompras.addLast("Sabão");

        System.out.println("\nInserindo elementos na primeira e última posição:");
        for (String item : listaDeCompras) {
            System.out.println(item);
        }
    }
}

