package semana10;

public class Aluno {
	protected String name;
	protected double ga,gb;
	public Aluno(String name, double ga, double gb) {
		this.name = name;
		this.ga = ga;
		this.gb = gb;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getGa() {
		return ga;
	}
	public void setGa(double ga) {
		this.ga = ga;
	}
	public double getGb() {
		return gb;
	}
	public void setGb(double gb) {
		this.gb = gb;
	}
	public double getNota(double ga, double gb) {
		double nota = (ga*0.33) + (gb*0.66);
		return nota;
	}
	@Override
	public String toString() {
		return "Aluno [name=" + name + ", ga=" + ga + ", gb=" + gb + "]";
	}
	
}
