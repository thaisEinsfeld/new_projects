package semana10;

import java.util.ArrayList;

public class teste_aluno {
    public static void main(String[] args) {
        ArrayList<Aluno> listaAlunos = new ArrayList<>();
        listaAlunos.add(new Aluno("Aluno1", 8.5, 7.0));
        listaAlunos.add(new Aluno("Aluno2", 7.0, 8.0));
        listaAlunos.add(new Aluno("Aluno3", 9.2, 9.5));

        Disciplina disciplina = new Disciplina(listaAlunos);
        
        System.out.println("Notas dos alunos:");
        disciplina.exibirNotas();

        double media = disciplina.calculaMedia();
        System.out.println("Média das notas: " + media);

        disciplina.exibirAprovados();
    }
}
