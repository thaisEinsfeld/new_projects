package exercicio_extra_ThaisEinsfeld;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
		 
		 System.out.print("Digite o tamanho da lista de contatos: ");
	     int tamanhoAgenda = scanner.nextInt();
	     
	     Agenda agenda = new Agenda(tamanhoAgenda);
	     
	     boolean continuar = true;
	     
	     while(continuar == true) {
	    	 System.out.println("Escolha uma opção:");
	         System.out.println("1. Inserir Contato");
	         System.out.println("2. Excluir Contato");
	         System.out.println("3. Pesquisar Contato");
	         System.out.println("4. Editar Contato");
	         System.out.println("5. Imprimir Contatos");
	         System.out.println("6. Sair");
	         int opcao = scanner.nextInt();
	         
	         if(opcao == 1) {
	        	 System.out.println("Digite o nome: ");
	             String nome = scanner.nextLine();
	             System.out.println("Digite o telefone: ");
	             String telefone = scanner.nextLine();
	             System.out.println("Digite o email: ");
	             String email = scanner.nextLine();
	             System.out.println("Digite o endereço: ");
	             String endereco = scanner.nextLine();
	             if (agenda.inserirContato(nome, telefone, email, endereco)) {
	                 System.out.println("Contato inserido com sucesso!");
	             } else {
	                 System.out.println("A agenda está cheia. Não foi possível inserir o contato.");
	             }
	         }else if(opcao == 2) {
	        	 System.out.print("Digite o nome do contato a ser excluído: ");
	             String nomeExcluir = scanner.nextLine();
	             if (agenda.excluirContato(nomeExcluir)) {
	                 System.out.println("Contato excluído com sucesso!");
	             } else {
	                 System.out.println("Contato não encontrado.");
	             }
	         }else if(opcao == 3) {
	        	 System.out.print("Digite o nome do contato a ser pesquisado: ");
	             String nomePesquisar = scanner.nextLine();
	             if (!agenda.pesquisarContato(nomePesquisar)) {
	                 System.out.println("Contato não encontrado.");
	             }
	         }else if(opcao == 4) {
	        	 System.out.print("Digite o nome do contato a ser editado: ");
	             String nomeEditar = scanner.nextLine();
	             if (!agenda.editarContato(nomeEditar)) {
	                 System.out.println("Contato não encontrado.");
	             }
	         }else if(opcao == 5) {
	        	 agenda.imprimirContatos();
	         }else if(opcao == 6) {
	        	 System.out.println("Encerrando a agenda.");
	         }else {
	             System.out.println("Opção inválida. Escolha novamente.");
	         }
	         
	         if (continuar) {
	                System.out.print("Deseja continuar? (S/N): ");
	                String resposta = scanner.next();
	                if (!resposta.equalsIgnoreCase("S")) {
	                    continuar = false;
	                    System.out.println("Encerrando a agenda.");
	                }
	            }
	         
	     }
         
	}

}
