package exercicio_extra_ThaisEinsfeld;
import java.util.Scanner;

public class Agenda {
	 	private String[][] contatos;
	    private int maxContatos;
	    private int numContatos;
	    
	    public Agenda(int maxContatos) {
	        this.maxContatos = maxContatos;
	        this.contatos = new String[maxContatos][4];
	        this.numContatos = 0;
	    }
	    
	    public boolean inserirContato(String nome, String telefone, String email, String endereco) {
	        if (numContatos < maxContatos) {
	            contatos[numContatos][0] = nome;
	            contatos[numContatos][1] = telefone;
	            contatos[numContatos][2] = email;
	            contatos[numContatos][3] = endereco;
	            numContatos++;
	            return true;
	        }
	        return false;
	    }
	    
	    public boolean excluirContato(String nome) {
	        for (int i = 0; i < numContatos; i++) {
	            if (contatos[i][0] != null && contatos[i][0].equalsIgnoreCase(nome)) {
	                contatos[i] = new String[4];
	                return true;
	            }
	        }
	        return false;
	    }
	    
	    public boolean pesquisarContato(String nome) {
	        for (int i = 0; i < numContatos; i++) {
	            if (contatos[i][0] != null && contatos[i][0].equalsIgnoreCase(nome)) {
	                imprimirContato(nome);
	                return true;
	            }
	        }
	        return false;
	    }
	    
	    public boolean editarContato(String nome) {
	        for (int i = 0; i < numContatos; i++) {
	            if (contatos[i][0] != null && contatos[i][0].equalsIgnoreCase(nome)) {
	                Scanner scanner = new Scanner(System.in);
	                System.out.println("Escolha o dado para editar:");
	                System.out.println("1. Nome");
	                System.out.println("2. Telefone");
	                System.out.println("3. Email");
	                System.out.println("4. Endereço");
	                int opcao = scanner.nextInt();
	                
	                System.out.print("Digite o novo valor: ");
	                String novoValor = scanner.nextLine();
	                
	                contatos[i][opcao - 1] = novoValor;
	                System.out.println("Contato editado com sucesso!");
	                return true;
	            }
	        }
	        return false;
	    }
	    
	    public void imprimirContato(String nome) {
	        for (int i = 0; i < numContatos; i++) {
	            if (contatos[i][0] != null && contatos[i][0].equalsIgnoreCase(nome)) {
	                System.out.println("Informações do contato:");
	                System.out.println("Nome: " + contatos[i][0]);
	                System.out.println("Telefone: " + contatos[i][1]);
	                System.out.println("Email: " + contatos[i][2]);
	                System.out.println("Endereço: " + contatos[i][3]);
	                return;
	            }
	        }
	        System.out.println("Contato não encontrado.");
	    }

	    public void imprimirContatos() {
	        System.out.println("Lista de Contatos:");
	        for (int i = 0; i < numContatos; i++) {
	            if (contatos[i][0] != null) {
	                System.out.println("Contato " + (i + 1) + ":");
	                System.out.println("Nome: " + contatos[i][0]);
	                System.out.println("Telefone: " + contatos[i][1]);
	                System.out.println("Email: " + contatos[i][2]);
	                System.out.println("Endereço: " + contatos[i][3]);
	                System.out.println("--------------------");
	            }
	        }
	    }

	    
}
