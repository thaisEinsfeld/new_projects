package aula4;

import java.util.Scanner;

public class Principal 
{
    public static void main(String[] args) 
    {
        Scanner ler = new Scanner(System.in);
        System.out.print("Digite a quantidade de churros disponível na banca: ");
        int tam = ler.nextInt();
        int saborChurros;
        BancaDeChurros bc = new BancaDeChurros(tam);
        for(int i = 0; i < tam; i++){
            do{
                System.out.println("Digite o sabor do churro: ");
                System.out.println("1-Tradicional");
                System.out.println("2-Doce de leite");
                System.out.println("3-Chocolate");
                saborChurros = ler.nextInt();
            } while(saborChurros < 1 || saborChurros > 3);
            
            if(saborChurros == 1)
                bc.insereChurro(new Churros("Tradicional", saborChurros*2.5));
            else if(saborChurros == 2)
                bc.insereChurro(new Churros("Doce de leite", saborChurros*2.5));
            else if(saborChurros == 3)
                bc.insereChurro(new Churros("Chocolate", saborChurros*2.5));
        }
        System.out.println("------------ Churros originais ------------");
        bc.imprimeChurros();

        //bc.lePedidos("Maria", "Doce de leite", 1);
        bc.lePedidos("Maria", "Doce de leite", 3);

        System.out.println("\n------------ Churros após compra ------------");
        bc.imprimeChurros();

        bc.insereChurro(new Churros("Tradicional", 2.5));

        System.out.println("\n------------ Churros após inserir novo Churro ------------");
        bc.imprimeChurros();
    }
}
