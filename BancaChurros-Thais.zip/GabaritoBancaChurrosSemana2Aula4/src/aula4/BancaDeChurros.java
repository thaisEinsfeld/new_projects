package aula4;

public class BancaDeChurros {
	private Churros[] churros;

    public BancaDeChurros(int quant){
        churros = new Churros[quant]; //instância o array com o tamanho recebido
    }

    /* estoqueChurros: este método recebe uma String sabor e retorna a quantidade de churros
    daquele sabor estão presentes no array. */
    public int estoqueChurros(String sabor){
        int quant = 0;
        for(int i=0; i<churros.length; i++){
            if(churros[i] != null) {
                if(churros[i].getSabor().equalsIgnoreCase(sabor))
                    quant++;
            }
        }
        return quant;
    }

    /* insereChurro: este método recebe um objeto do tipo Churros por parâmetro e insere este objeto
    na primeira posição livre do array (ou seja, com null). O método retorna verdadeiro caso insira o
    churro ou falso caso contrário. */
    public boolean insereChurro(Churros c){
        for(int i=0; i<churros.length; i++){
            if(churros[i] == null){
                churros[i] = c;
                System.out.println("Churro inserido no índice " + i);
                return true;
            }
        }
        System.out.println("Não foi possível inserir churro! Banca lotada!");
        return false;
    }

    /* valorTotal: este método retorna o preço total dos churros no array. */
    public double valorTotal(){
        double total = 0;
        for(int i=0; i<churros.length; i++){
            if(churros[i] != null){
                total += churros[i].getPreco();
            }
        }
        return total;
    }

    /* vendeChurros: este método recebe uma String sabor e vende um churro daquele sabor,
    retirando-o do array. O método imprime o valor da compra e retornar verdadeiro caso o churro
    tenha sido vendido. Caso não exista churros daquele sabor, imprima uma mensagem informativa e
    retorne falso. */
    public boolean vendeChurros(String sabor){
        int quantChurros = estoqueChurros(sabor);
        if(quantChurros == 0){
            System.out.println("Não existe(m) mais churro(s) do sabor "+sabor+" :-(");
            return false;
        }
        for(int i=0; i<churros.length; i++){
            if(churros[i] != null){
                if(churros[i].getSabor().equalsIgnoreCase(sabor)){
                    System.out.println("Valor do(s) churro(s): R$ "+churros[i].getPreco());
                    churros[i] = null;
                    break;
                }
            }
        }
        return true;
    }

    /* imprimeChurros: este método imprime as informações de todos os churros do array (um churro
    em cada linha). */
    public void imprimeChurros(){
        for(int i = 0; i < churros.length; i++){
            if(churros[i] != null){
                System.out.println(churros[i].toString());
            }
        }
    }

    /* lePedidos: este método recebe uma String nome, uma String sabor e um inteiro quantidade. Este
    método deve tentar vender esta quantidade de churros, informando sucesso ou insucesso a cada
    venda. */
    public void lePedidos(String nome, String sabor, int quantidade){
        if(estoqueChurros(sabor) >= quantidade){
            for(int i=0; i<quantidade; i++)
                vendeChurros(sabor);
                
            System.out.println("Churro(s) comprado(s) :-)");
        } else
            System.out.println("Não foi possível comprar "+quantidade+" churro(s) de "+sabor+" :-(");
    }
}
